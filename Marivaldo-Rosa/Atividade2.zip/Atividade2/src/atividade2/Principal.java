package atividade2;

public class Principal {

    public static void main(String[] args) {
      
        
      Piramide x = new Piramide();
      x.setBase(36);
      x.setAltura(9);
      
      System.out.println("VOLUME DA PIRAMIDE:\n");
      System.out.println("Volume: "+x.calcVolume()+" cm³");
    
    }
    
}
