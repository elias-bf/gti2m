
package atividade1;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        
        Scanner s = new Scanner (System.in);
        
        Esfera x = new Esfera ();
        x.setRaio(3.0);
        
        System.out.println("\nDADOS DA ESFERA\n");
        System.out.println("raio: "+ x.getRaio());
        System.out.println("área: "+ x.calcArea());
        System.out.println("volume: "+ x.calcVolume());
        
        Esfera y = new Esfera (2.0);
        /*y.setRaio(6.0);   Não precisa por ja esta chamando no [ESFERA]*/
        
        System.out.println("\nDADOS DA ESFERA\n");
        System.out.println("raio: "+ y.getRaio());
        System.out.println("área: "+ y.calcArea());
        System.out.println("volume: "+ y.calcVolume());
        
        s.close();
        
        
    }
    
}
