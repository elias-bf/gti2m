
package atividade1;

public class Esfera {
    
    private double raio;
 
    public Esfera(){
    
    }
    
    public Esfera(double raio){
        this.raio = raio;
    }
    /*Altera valor*/
    public void setRaio(double raio){
        /*Usa this porque é ATRIBUTO*/
        this.raio = raio;
    }
    /*Desmostravalor, retornar valor, ter retorno. precisa ser double*/
    public double getRaio(){
        /*Usa return porque é PARAMÊTRO*/
        return raio;
    }
    
    
    @Override /*Procurar saber*/
    public String toString(){
        return "[Esfera] raio :"+raio;
    }
    
    public double calcArea(){
        return 4*3.14*raio*raio;
    }
    
    public double calcVolume(){
       return ((4.0/3)*3.14*raio*raio*raio); 
    }
    
    
    
    
}

