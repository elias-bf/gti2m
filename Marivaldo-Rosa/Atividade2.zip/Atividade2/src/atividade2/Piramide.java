package atividade2;

public class Piramide {
    
    
    private double base;
    private double altura;
    
    //metodos
    public void setBase (double base){
        this.base = base;
    }
    public void setAltura (double altura){
        this.altura = altura;
    }
   
    public double getBase (){
        return base;
    }
    public double getAltura(){
        return altura;
    }
    public double calcVolume(){
        return (base*altura)/3;
    }
}
